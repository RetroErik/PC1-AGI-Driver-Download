AGI Driver for Olivetti Prodest PC1
By Retro Erik, 2026

True 16-color EGA graphics for Sierra AGI games on the Olivetti Prodest PC1.

USAGE
=====
1. Copy the CGA_GRAF.OVL from the correct game folder to your game disk,
   replacing the original.

2. Run AGIPAL.COM once before launching the game:
     AGIPAL
     KQ1

   Use AGIPAL /R to reset the palette to defaults.

CONTENTS
========
AGIPAL.COM        - EGA palette loader (run once before game)
KQ1\CGA_GRAF.OVL  - King's Quest I
KQ2\CGA_GRAF.OVL  - King's Quest II
KQ3\CGA_GRAF.OVL  - King's Quest III
LSL\CGA_GRAF.OVL  - Leisure Suit Larry
PQ1\CGA_GRAF.OVL  - Police Quest I
SQ1\CGA_GRAF.OVL  - Space Quest I
SQ2\CGA_GRAF.OVL  - Space Quest II

NOTE: Each overlay is specific to the game and version it was built for.
If your version doesn't work, or if you want support for an AGI game
not listed here, send me your original CGA_GRAF.OVL and I will patch
it for you.

REQUIRES: Olivetti Prodest PC1 (or compatible with Yamaha V6355D)
           + original AGI game files

YOUTUBE: https://www.youtube.com/@RetroErik
